> v3.2.0
* 修复单独pip安装时因为翻译'_'模块无法使用的问题
* 支持v2rayN quic vmess分享格式

> v3.1.0
* 修复翻译错误, 流量统计乱码

> v3.0.7
* support chinese && english switch
* check v2ray log
* [#163](https://github.com/Jrohy/multi-v2ray/issues/163)
* [#168](https://github.com/Jrohy/multi-v2ray/issues/168)

> v3.0.6
* Change to pip install
* [#152](https://github.com/Jrohy/multi-v2ray/issues/152)
* [#155](https://github.com/Jrohy/multi-v2ray/issues/155)

> v2.6.3.1
* fix some bug

> v2.6.3
* [#107](https://github.com/Jrohy/multi-v2ray/issues/107)
* [#108](https://github.com/Jrohy/multi-v2ray/issues/108)
* support zsh

> v2.6.2
* [#106](https://github.com/Jrohy/multi-v2ray/issues/106)

> v2.6.1
* [#99](https://github.com/Jrohy/multi-v2ray/issues/99)
* Fix del mtproto port

> v2.6.0
* [#95](https://github.com/Jrohy/multi-v2ray/issues/95)
* [#96](https://github.com/Jrohy/multi-v2ray/issues/96)
* 增加iptables端口流量统计

> v2.5.3
* [#82](https://github.com/Jrohy/multi-v2ray/issues/82)
* Fix force update bug

> v2.5.2
* [#78](https://github.com/Jrohy/multi-v2ray/issues/78)
* [#80](https://github.com/Jrohy/multi-v2ray/issues/80)

> v2.5.1
* 加入更新脚本特定版本指令

> v2.5.0  
* 更新策略更改, 只用最新的Release版本更新, 亦可指定版本更新(回退)
* 增加版本信息显示

> v2.4
* 支持Quic
* 加入更新v2ray到特定版本的指令

> v2.3
* Add Flask web接口
* 精简json模板

> v2.2
* 加入禁止BT

> v2.1
* 代码重构，加入json文件缓存

> v2.0
* 代码重构，加入json文件缓存

> v1.0